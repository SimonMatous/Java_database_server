create trigger ARC_ARC_2_FPS
    before insert or update of NAZEV
    on FPS
    for each row
DECLARE
    d VARCHAR2(100 CHAR);
BEGIN
    SELECT
        a.hra_typ_nazev
    INTO d
    FROM
        hra a
    WHERE
        a.nazev = :new.nazev;

    IF ( d IS NULL OR d <> 'fps' ) THEN
        raise_application_error(-20223, 'FK fps_hra_FK in Table fps violates Arc constraint on Table hra - discriminator column hra_typ_nazev doesn''t have value ''fps''');
    END IF;

EXCEPTION
    WHEN no_data_found THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/

