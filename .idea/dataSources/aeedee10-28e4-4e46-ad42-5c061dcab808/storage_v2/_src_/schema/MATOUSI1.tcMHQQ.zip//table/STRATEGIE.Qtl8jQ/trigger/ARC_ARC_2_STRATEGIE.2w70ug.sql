create trigger ARC_ARC_2_STRATEGIE
    before insert or update of NAZEV
    on STRATEGIE
    for each row
DECLARE
    d VARCHAR2(100 CHAR);
BEGIN
    SELECT
        a.hra_typ_nazev
    INTO d
    FROM
        hra a
    WHERE
        a.nazev = :new.nazev;

    IF ( d IS NULL OR d <> 'strategie' ) THEN
        raise_application_error(-20223, 'FK strategie_hra_FK in Table strategie violates Arc constraint on Table hra - discriminator column hra_typ_nazev doesn''t have value ''strategie''');
    END IF;

EXCEPTION
    WHEN no_data_found THEN
        NULL;
    WHEN OTHERS THEN
        RAISE;
END;
/

