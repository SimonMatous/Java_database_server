create view SOFT as
select  s.lokace_id, s.software_nazev
    from software s 
    join relation_6 r on r.software_nazev = s.software_nazev
    join hra h on h.nazev = r.nazev
    join studio s on s.studio_nazev = h.studio_nazev
/

